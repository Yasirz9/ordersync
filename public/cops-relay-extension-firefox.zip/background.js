import { getAccessToken, fetchPending, claimRequest, updateRequest } from "./sb.js";
import { DEFAULT_PORTAL_URL } from "./config.js";
const POLL_ALARM = "poll-pending";
chrome.runtime.onInstalled.addListener(() => chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 }));
chrome.alarms.onAlarm.addListener((a) => { if (a.name === POLL_ALARM) poll(); });
chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (msg?.type === "poll") { poll().then(() => sendResponse({ ok: true })); return true; }
  if (msg?.type === "status") { getStatus().then(sendResponse); return true; }
});
async function getStatus() {
  const token = await getAccessToken().catch(() => null);
  const { last_poll_at, last_error, processed_count } = await chrome.storage.local.get(["last_poll_at","last_error","processed_count"]);
  return { signed_in: !!token, last_poll_at: last_poll_at || null, last_error: last_error || null, processed_count: processed_count || 0 };
}
async function poll() {
  try {
    const token = await getAccessToken().catch(() => null);
    if (!token) return;
    const pending = await fetchPending();
    await chrome.storage.local.set({ last_poll_at: Date.now(), last_error: null });
    for (const req of pending) {
      const claimed = await claimRequest(req.id);
      if (!claimed) continue;
      try {
        const result = await fetchOrderFromPortal(req.order_number);
        await updateRequest(req.id, { status: "completed", result });
        const { processed_count = 0 } = await chrome.storage.local.get("processed_count");
        await chrome.storage.local.set({ processed_count: processed_count + 1 });
      } catch (err) {
        await updateRequest(req.id, { status: "failed", error_message: String(err?.message || err).slice(0, 500) });
      }
    }
  } catch (err) {
    await chrome.storage.local.set({ last_error: String(err?.message || err) });
  }
}
async function fetchOrderFromPortal(orderNumber) {
  const { portal_url_template } = await chrome.storage.local.get("portal_url_template");
  const url = portal_url_template || DEFAULT_PORTAL_URL;
  const today = new Date();
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const dd = String(today.getDate()).padStart(2, "0");
  const yyyy = today.getFullYear();
  const endDate = `${mm}/${dd}/${yyyy}`;
  const startDate = `01/01/2026`;
  const body = {
    startdate: startDate,
    enddate: endDate,
    zone: "All",
    region: "All",
    exchange: "All",
    orderNumber: String(orderNumber),
    statuses: "All",
  };
  const res = await fetch(url, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json; charset=utf-8", Accept: "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Portal returned ${res.status} (check VPN + login)`);
  const ctype = res.headers.get("content-type") || "";
  if (!ctype.includes("json")) {
    const text = await res.text();
    throw new Error(`Session expired or error page. Re-login to cops.ptml.pk. (${text.slice(0, 200)})`);
  }
  const json = await res.json();
  const records = Array.isArray(json?.d) ? json.d : [];
  const match = records.find((r) => String(r.order_number) === String(orderNumber)) || records[0] || null;
  return { type: "record", url, found: !!match, count: records.length, record: match, all: records };
}
function extractFirstTable(html) {
  const m = html.match(/<table[\s\S]*?<\/table>/i);
  if (!m) return null;
  const t = m[0];
  const headers = [...t.matchAll(/<th[^>]*>([\s\S]*?)<\/th>/gi)].map((x) => stripHtml(x[1]).trim());
  const rows = [];
  for (const r of [...t.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]) {
    const cells = [...r[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((x) => stripHtml(x[1]).trim());
    if (cells.some((c) => c.length > 0)) rows.push(cells);
  }
  return { headers, rows };
}
function stripHtml(s) {
  return s.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s+/g, " ");
}